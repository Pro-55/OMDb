package com.example.omdb.listmodule

import com.example.omdb.network.responce.SearchData

interface IMovieList {
    fun showMovieDetails(searchData: SearchData)
}
