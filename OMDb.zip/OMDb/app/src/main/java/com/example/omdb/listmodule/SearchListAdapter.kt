package com.example.omdb.listmodule

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.omdb.R
import com.example.omdb.network.responce.SearchData
import kotlinx.android.synthetic.main.layout_movie_list_item.view.*
import java.util.*

class SearchListAdapter(private val mContext: Context, private val mIMovieList: IMovieList) : RecyclerView.Adapter<SearchListAdapter.ItemViewHolder>() {
    private var searchList: ArrayList<SearchData>? = null

    init {
        searchList = ArrayList()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.layout_movie_list_item, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val searchData = searchList!![position]
        val url = searchData.poster
        if (url != null) {
            Glide.with(mContext)
                    .load(url)
                    .apply(RequestOptions.circleCropTransform())
                    .into(holder.itemView.idIvMoviePoster)
        } else {
            Glide.with(mContext)
                    .load(R.drawable.ic_default_image)
                    .apply(RequestOptions.circleCropTransform())
                    .into(holder.itemView.idIvMoviePoster)
        }
        holder.itemView.idTvMovieTitle.text = searchData.title
        holder.itemView.idTvMovieYear.text = searchData.year
        holder.itemView.setOnClickListener { mIMovieList.showMovieDetails(searchData) }
    }

    override fun getItemCount(): Int {
        return searchList!!.size
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    fun updateUserList(searchList: ArrayList<SearchData>) {
        this.searchList!!.clear()
        this.searchList = searchList
        notifyDataSetChanged()
    }

    fun clearUserList() {
        this.searchList!!.clear()
        notifyDataSetChanged()
    }
}
