package com.example.omdb.detailsmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.omdb.R

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
    }
}
