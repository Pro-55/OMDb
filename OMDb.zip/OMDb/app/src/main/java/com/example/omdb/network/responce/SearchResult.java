package com.example.omdb.network.responce;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchResult {

    @SerializedName("SearchData")
    @Expose
    private List<SearchData> searchList = null;

    public List<SearchData> getSearchList() {
        return searchList;
    }

    public void setSearchList(List<SearchData> searchList) {
        this.searchList = searchList;
    }
}
