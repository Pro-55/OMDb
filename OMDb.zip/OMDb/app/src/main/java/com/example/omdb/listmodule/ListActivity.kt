package com.example.omdb.listmodule

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.omdb.R
import com.example.omdb.network.responce.SearchData
import com.jakewharton.rxbinding.widget.RxTextView
import kotlinx.android.synthetic.main.activity_main.*
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import java.util.concurrent.TimeUnit

class ListActivity : AppCompatActivity(), IMovieList {

    private val TAG = "ListActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //RecyclerView Setup
        idRvMovieSearchList.adapter = SearchListAdapter(applicationContext, this)

        RxTextView.textChanges(idEtMovieSearchBox)
                .skip(1)
                .debounce(300, TimeUnit.MILLISECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<CharSequence>() {
                    override fun onCompleted() {
                        Log.d(TAG, "TestLog: onCompleted")
                    }

                    override fun onError(e: Throwable) {
                        Log.d(TAG, "TestLog: ${e.message}")
                    }

                    override fun onNext(charSequence: CharSequence) {
                        Log.d(TAG, "TestLog: $charSequence")
                    }
                })
    }

    override fun showMovieDetails(searchData: SearchData) {
        Log.d(TAG, "TestLog: $searchData")
    }
}
