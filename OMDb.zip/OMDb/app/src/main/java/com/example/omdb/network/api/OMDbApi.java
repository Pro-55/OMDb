package com.example.omdb.network.api;

import com.example.omdb.network.responce.SearchResult;

import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

public interface OMDbApi {

    @GET("/")
    Observable<SearchResult> searchMovies(@Query("apikey") String sessionID,
                                          @Query("s") String movieTitle,
                                          @Query("page") int page);

    @GET("/")
    Observable<SearchResult> getMovieDetails(@Query("apikey") String sessionID,
                                             @Query("i") String movieID);

}