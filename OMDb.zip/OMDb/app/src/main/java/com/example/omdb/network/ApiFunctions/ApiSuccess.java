package com.example.omdb.network.ApiFunctions;

import rx.functions.Action1;

public abstract class ApiSuccess<T> implements Action1<T> {

}
